# Sing-box Fragment

Starting from version 1.12.0 sing-box added tls fragment to its core. Panel is now providing fragment sub for sing-box, however, please note that fragment settings in panel are not affecting sing-box config because it only has 1 mod available and is not flexible. It works by the way.

> [!WARNING]
> Please use [1.12.0-beta.28](https://github.com/SagerNet/sing-box/releases/tag/v1.12.0-beta.28) or higher versions of sing-box.

## ⚙️ Bug fixes and Improvements

- Fixed Russia routing rules bug.
