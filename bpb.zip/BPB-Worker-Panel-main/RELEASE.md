# ⚙️ Bug fixes and Improvements

- Added proxy IPs link to panel
- Added `Copy all` to secrets generator, PR #975
- Revised Xray DNS hijack to adjust with recent v2rayNG version

> [!TIP]
> You can now copy all environment variables and just copy into `Variable name` field in Cloudflare dashboard instead of creating env vars one by one.
