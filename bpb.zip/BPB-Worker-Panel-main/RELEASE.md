# ⚙️ Bug fixes and Improvements

- Refactored, much less worker Error rate
- Fixed Clash NAT64 #1016
- Added Xray TFO
