# ⚙️ Bug fixes and Improvements

- Added VLESS/Trojan fingerprint selection to panel
- Removed sing-box outbound domain_resolver, will deprecate in 1.14
- Refactored
