# ⚙️ Bug fixes and Improvements

- Fixed Warp PRO subscription #895.
- Updated docs.
