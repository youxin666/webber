# ⚙️ Bug fixes and Improvements

- Fixed Fingerprint not applied to Normal configs
- Display errors in same page
