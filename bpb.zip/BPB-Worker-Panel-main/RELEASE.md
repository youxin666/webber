# ⚙️ Bug fixes and Improvements

- Revised DNS hijack in Xray and sing-box.
- Added scheduled build. The project will be built every 3 hourse to prevent Cloudflare 1101 errors.
- UI bug fix.
