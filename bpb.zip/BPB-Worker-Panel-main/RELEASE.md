# ⚙️ Bug fixes and Improvements

- Another attempt to bypass Cloudflare 1101 error #940
- Removed obfuscation
- Build every 1 hour
