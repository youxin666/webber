# ⚙️ Bug fixes and Improvements

- Removed `Normal` subscription due to poor efficiency and user errors and renamed `Full Normal` to `Normal`
- Removed support for some deprecated clients which are not sync to cores changes or modify configs after import like `Hiddify`
- Changed some subscriptions URL
- Added help refrences to Panel
- Refactored project
- Updated docs
- Bug fix #1022
- Bug fix, custom rules IP CIDR validation

> [!CAUTION]
> Some subscription URLs are changed, so you have to get new subscriptions from panel again.
