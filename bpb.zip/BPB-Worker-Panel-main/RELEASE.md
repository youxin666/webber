# ⚙️ Bug fixes and Improvements

- Added `happyEyeballs` to Xray (VLESS, Trojan and WorkerLess)
- Fixed WorkerLess Stats not showing in v2rayNG
- Revised Clash custom IP rules
- Pruned some legacy clients from code
- UI improvements
- Refactored, code readability
- Panel bug fixes
