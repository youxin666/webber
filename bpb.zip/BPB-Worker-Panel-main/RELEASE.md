# ⚙️ Bug fixes and Improvements

- Fixed missing IPv6 configs #1000
- Fixed WorkerLess malfunctioning with Fake DNS enabled
- Refactored
